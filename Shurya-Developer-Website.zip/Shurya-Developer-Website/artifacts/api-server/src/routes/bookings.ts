import { ReplitConnectors } from "@replit/connectors-sdk";
import { Router, type IRouter } from "express";

const router: IRouter = Router();
const connectors = new ReplitConnectors();
const OWNER_EMAIL = "shurya289@gmail.com";

type BookingInput = {
  name: string;
  phone: string;
  email: string;
  day: string;
  slot: string;
};

function isBookingInput(value: unknown): value is BookingInput {
  if (!value || typeof value !== "object") return false;

  const booking = value as Record<string, unknown>;
  return (
    typeof booking.name === "string" &&
    booking.name.trim().length > 0 &&
    typeof booking.phone === "string" &&
    booking.phone.replace(/\D/g, "").length >= 10 &&
    typeof booking.email === "string" &&
    /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(booking.email) &&
    typeof booking.day === "string" &&
    booking.day.trim().length > 0 &&
    typeof booking.slot === "string" &&
    booking.slot.trim().length > 0
  );
}

function encodeBase64Url(value: string) {
  return Buffer.from(value, "utf8")
    .toString("base64")
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/g, "");
}

router.post("/bookings/notify", async (req, res) => {
  if (!isBookingInput(req.body)) {
    res.status(400).json({ message: "Please provide valid booking details." });
    return;
  }

  const booking = req.body;
  const subject = `New booking from ${booking.name}`;
  const body = [
    "New Shurya Developer booking",
    "",
    `Name: ${booking.name}`,
    `Phone: ${booking.phone}`,
    `Email: ${booking.email}`,
    `Date: ${booking.day}`,
    `Time: ${booking.slot}`,
    "Service: E-commerce website",
    "Price: ₹5,999",
    "UPI ID: 9650787601@ptype",
  ].join("\n");

  const rawMessage = [
    `To: ${OWNER_EMAIL}`,
    `From: Shurya Developer <${OWNER_EMAIL}>`,
    `Subject: ${subject}`,
    "Content-Type: text/plain; charset=UTF-8",
    "",
    body,
  ].join("\r\n");

  try {
    const response = await connectors.proxy(
      "google-mail",
      "/gmail/v1/users/me/messages/send",
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ raw: encodeBase64Url(rawMessage) }),
      },
    );

    if (!response.ok) {
      const providerMessage = await response.text();
      req.log.error(
        { status: response.status, providerMessage },
        "Gmail booking notification failed",
      );
      res.status(502).json({ message: "Could not send the booking notification." });
      return;
    }

    res.json({
      sent: true,
      ownerEmail: OWNER_EMAIL,
      message: "Booking notification sent.",
    });
  } catch (error) {
    req.log.error({ err: error }, "Gmail booking notification request failed");
    res.status(502).json({ message: "Could not send the booking notification." });
  }
});

export default router;