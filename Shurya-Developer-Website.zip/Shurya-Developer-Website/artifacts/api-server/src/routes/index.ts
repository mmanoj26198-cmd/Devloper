import { Router, type IRouter } from "express";
import bookingsRouter from "./bookings";
import healthRouter from "./health";

const router: IRouter = Router();

router.use(healthRouter);
router.use(bookingsRouter);

export default router;
