import { type FormEvent, type ReactNode, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import {
  ArrowDown,
  ArrowRight,
  ArrowUpRight,
  Check,
  CheckCircle2,
  ChevronLeft,
  Clock3,
  Copy,
  ExternalLink,
  Instagram,
  MapPin,
  Menu,
  MessageCircle,
  Phone,
  ShieldCheck,
  Sparkles,
  X,
  Zap,
} from 'lucide-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { useNotifyBooking } from '@workspace/api-client-react';
import NotFound from '@/pages/not-found';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';

const queryClient = new QueryClient();

const availableDays = Array.from({ length: 14 }, (_, index) => {
  const day = new Date();
  day.setHours(12, 0, 0, 0);
  day.setDate(day.getDate() + index + 1);
  return {
    iso: day.toISOString().slice(0, 10),
    weekday: day.toLocaleDateString('en-IN', { weekday: 'short' }),
    date: day.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' }),
    full: day.toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' }),
  };
});

const appointmentSlots = ['10:00 AM', '12:30 PM', '3:00 PM', '5:30 PM', '7:00 PM'];
const UPI_ID = '9650787601@ptype';

type BookingDetails = {
  day: string;
  slot: string;
  name: string;
  phone: string;
  email: string;
};

function scrollToBooking() {
  document.getElementById('booking')?.scrollIntoView({ behavior: 'smooth' });
}

function AppMark({ small = false }: { small?: boolean }) {
  return (
    <span className={`relative inline-flex items-center justify-center ${small ? 'h-9 w-9' : 'h-12 w-12'}`} aria-hidden="true">
      <span className="absolute inset-0 rotate-45 rounded-[0.45rem] bg-[#e7b94b]" />
      <span className={`display-font relative font-extrabold text-[#14120f] ${small ? 'text-lg' : 'text-2xl'}`}>S</span>
    </span>
  );
}

function Header() {
  const [menuOpen, setMenuOpen] = useState(false);
  const links = [
    { label: 'What we do', href: '#work' },
    { label: 'How it works', href: '#process' },
    { label: 'Book a build', href: '#booking' },
  ];
  return (
    <header className="absolute left-0 right-0 top-0 z-30">
      <div className="container-wide flex items-center justify-between border-b border-white/15 py-5">
        <a href="#top" className="focus-ring flex items-center gap-3" data-testid="link-logo">
          <AppMark small />
          <span className="display-font text-base font-bold tracking-tight text-[#f6f0e5]">Shurya Developer</span>
        </a>
        <nav className="hidden items-center gap-8 md:flex" aria-label="Main navigation">
          {links.map((link) => (
            <a key={link.href} href={link.href} className="focus-ring text-sm font-medium text-[#e9e1d4]/75 transition-colors hover:text-[#e7b94b]" data-testid={`link-nav-${link.label.toLowerCase().replaceAll(' ', '-')}`}>
              {link.label}
            </a>
          ))}
        </nav>
        <button
          type="button"
          onClick={() => setMenuOpen((open) => !open)}
          className="focus-ring rounded-full border border-white/20 p-2 text-[#f6f0e5] md:hidden"
          aria-label={menuOpen ? 'Close navigation menu' : 'Open navigation menu'}
          data-testid="button-mobile-menu"
        >
          {menuOpen ? <X size={19} /> : <Menu size={19} />}
        </button>
      </div>
      {menuOpen && (
        <nav className="container-wide mx-auto flex flex-col gap-1 border-b border-white/15 bg-[#171512] px-5 py-4 md:hidden" aria-label="Mobile navigation">
          {links.map((link) => (
            <a key={link.href} href={link.href} onClick={() => setMenuOpen(false)} className="focus-ring px-2 py-3 text-sm font-semibold text-[#f6f0e5]" data-testid={`link-mobile-${link.label.toLowerCase().replaceAll(' ', '-')}`}>
              {link.label}
            </a>
          ))}
        </nav>
      )}
    </header>
  );
}

function Hero() {
  return (
    <section id="top" className="relative min-h-[720px] overflow-hidden bg-[#171512] text-[#f6f0e5]">
      <div className="absolute -right-28 top-28 h-[460px] w-[460px] rounded-full border border-[#e7b94b]/20 md:right-[8%] md:top-[18%]" />
      <div className="absolute -right-8 top-56 h-[310px] w-[310px] rounded-full border border-[#e7b94b]/30 md:right-[13%] md:top-[27%]" />
      <div className="absolute right-[18%] top-[43%] hidden h-3 w-3 rounded-full bg-[#e7b94b] shadow-[0_0_0_9px_rgba(231,185,75,0.13)] md:block" />
      <Header />
      <div className="container-wide relative flex min-h-[720px] items-end pb-16 pt-36 md:items-center md:pb-20 md:pt-28">
        <div className="max-w-3xl">
          <div className="animate-rise inline-flex items-center gap-2 rounded-full border border-[#e7b94b]/35 bg-[#e7b94b]/10 px-3 py-2 text-[0.68rem] font-bold uppercase tracking-[0.18em] text-[#e7b94b]">
            <span className="h-1.5 w-1.5 rounded-full bg-[#e7b94b]" /> Local business, properly online
          </div>
          <h1 className="display-font animate-rise animate-rise-1 mt-7 max-w-[850px] text-[clamp(4rem,13vw,9.7rem)] font-extrabold leading-[0.86] tracking-[-0.07em]">
            Build your <span className="text-[#e7b94b]">online shop</span>
          </h1>
          <p className="animate-rise animate-rise-2 mt-8 max-w-md text-lg leading-relaxed text-[#e9e1d4]/68 md:text-xl">
            Aaj se aapke paas client hi client
          </p>
          <div className="animate-rise animate-rise-3 mt-9 flex flex-col gap-3 sm:flex-row sm:items-center">
            <button type="button" onClick={scrollToBooking} className="focus-ring group inline-flex items-center justify-center gap-4 rounded-full bg-[#e7b94b] px-6 py-4 text-sm font-bold text-[#171512] transition-transform hover:-translate-y-1" data-testid="button-hero-book">
              Book now <ArrowRight size={17} className="transition-transform group-hover:translate-x-1" />
            </button>
            <a href="#work" className="focus-ring inline-flex items-center justify-center gap-2 px-4 py-4 text-sm font-semibold text-[#f6f0e5]/75 transition-colors hover:text-[#e7b94b]" data-testid="link-hero-work">
              See what gets built <ArrowDown size={16} />
            </a>
          </div>
        </div>
        <div className="animate-float-mark absolute bottom-20 right-7 hidden h-28 w-28 rotate-[-12deg] items-center justify-center border border-[#e7b94b]/60 md:flex">
          <div className="text-center text-[0.6rem] font-bold uppercase tracking-[0.18em] text-[#e7b94b]">Delhi<br />to<br />digital</div>
        </div>
      </div>
      <div className="absolute bottom-0 left-0 right-0 overflow-hidden border-t border-[#e7b94b]/20 bg-[#e7b94b] py-3 text-[#171512]">
        <div className="marquee-track flex w-max items-center gap-8 text-xs font-bold uppercase tracking-[0.2em]">
          {Array.from({ length: 8 }, (_, index) => <span key={index} className="flex items-center gap-8">Shop online. Get found. Get paid. <span className="text-lg" aria-hidden="true">/</span></span>)}
        </div>
      </div>
    </section>
  );
}

function WorkSection() {
  return (
    <section id="work" className="bg-[#f4eee3] py-24 text-[#171512] md:py-32">
      <div className="container-wide">
        <div className="grid gap-12 md:grid-cols-[0.8fr_1.2fr] md:gap-20">
          <div>
            <p className="section-kicker text-[#9a721b]">The point is simple</p>
            <h2 className="display-font mt-5 max-w-sm text-5xl font-bold leading-[0.95] tracking-[-0.05em] md:text-7xl">Your shop deserves more than a WhatsApp forward.</h2>
            <a href="https://mmanoj26198-cmd.github.io/Mm-vloggers-/" target="_blank" rel="noreferrer" className="focus-ring mt-8 inline-flex items-center gap-2 text-sm font-bold underline decoration-[#e7b94b] decoration-2 underline-offset-4 transition-colors hover:text-[#9a721b]" data-testid="link-proof-shop">
              See a live shop we built <ExternalLink size={15} />
            </a>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            {[
              { number: '01', title: 'A real storefront', copy: 'Your products, prices, photos and story in one place customers can open any time.', icon: <Sparkles size={19} /> },
              { number: '02', title: 'Made for the phone', copy: 'Fast, thumb-friendly and clear enough for a customer browsing from the market queue.', icon: <Zap size={19} /> },
              { number: '03', title: 'Ready in 1 day', copy: 'No six-week agency theatre. We get the essentials live, then keep improving.', icon: <Clock3 size={19} /> },
              { number: '04', title: 'A person on call', copy: 'You talk to a local builder who understands how Delhi businesses actually work.', icon: <MessageCircle size={19} /> },
            ].map((item) => (
              <article key={item.number} className="group border-t border-[#171512]/20 pt-5 transition-transform hover:-translate-y-1">
                <div className="flex items-center justify-between text-[#9a721b]"><span className="text-xs font-bold tracking-[0.18em]">{item.number}</span>{item.icon}</div>
                <h3 className="display-font mt-10 text-2xl font-bold tracking-[-0.04em]">{item.title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-[#5d574f]">{item.copy}</p>
              </article>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function ProcessSection() {
  return (
    <section id="process" className="bg-[#e9dfcf] py-24 text-[#171512] md:py-32">
      <div className="container-wide">
        <div className="flex flex-col justify-between gap-7 border-b border-[#171512]/20 pb-8 md:flex-row md:items-end">
          <div>
            <p className="section-kicker text-[#9a721b]">No mystery, no maze</p>
            <h2 className="display-font mt-4 text-5xl font-bold leading-[0.92] tracking-[-0.05em] md:text-7xl">From “soch rahe hain”<br />to “share the link”.</h2>
          </div>
          <p className="max-w-xs text-sm leading-relaxed text-[#5d574f]">A focused sprint for owners who would rather serve customers than sit in a meeting about meetings.</p>
        </div>
        <div className="grid gap-0 pt-12 md:grid-cols-3">
          {[
            { step: '01', title: 'Pick a time', body: 'Choose a day and a slot that works for you. We keep the call practical.' },
            { step: '02', title: 'Send the basics', body: 'Share your shop name, contact details and what you sell. We take it from there.' },
            { step: '03', title: 'Go live', body: 'Your e-commerce website is ready in 1 day, with a clear next step for customers.' },
          ].map((item, index) => (
            <div key={item.step} className={`border-l border-[#171512]/20 py-2 pl-6 ${index === 0 ? 'md:pl-0 md:border-l-0' : 'md:pl-8'}`}>
              <span className="display-font text-6xl font-bold tracking-[-0.08em] text-[#c4a04e]">{item.step}</span>
              <h3 className="display-font mt-10 text-3xl font-bold tracking-[-0.05em]">{item.title}</h3>
              <p className="mt-3 max-w-xs text-sm leading-relaxed text-[#5d574f]">{item.body}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function BookingFlow() {
  const [step, setStep] = useState(1);
  const [selectedDay, setSelectedDay] = useState(availableDays[0].iso);
  const [selectedSlot, setSelectedSlot] = useState('');
  const [details, setDetails] = useState<BookingDetails>({ day: '', slot: '', name: '', phone: '', email: '' });
  const [error, setError] = useState('');
  const [copied, setCopied] = useState(false);
  const notifyBooking = useNotifyBooking();

  const chosenDay = availableDays.find((day) => day.iso === selectedDay) ?? availableDays[0];
  const updateDetail = (field: keyof BookingDetails, value: string) => setDetails((current) => ({ ...current, [field]: value }));

  const goToDetails = () => {
    if (!selectedSlot) {
      setError('Choose a time slot to continue.');
      return;
    }
    setError('');
    setDetails((current) => ({ ...current, day: selectedDay, slot: selectedSlot }));
    setStep(2);
  };

  const goToPayment = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!details.name.trim() || !details.phone.trim() || !details.email.trim()) {
      setError('Please fill in your name, phone and email.');
      return;
    }
    if (details.phone.replace(/\D/g, '').length < 10) {
      setError('Please enter a 10-digit phone number.');
      return;
    }
    setError('');
    setStep(3);
  };

  const completeBooking = async () => {
    setError('');
    try {
      await notifyBooking.mutateAsync({
        data: {
          name: details.name.trim(),
          phone: details.phone.trim(),
          email: details.email.trim(),
          day: chosenDay.full,
          slot: selectedSlot,
        },
      });
      setStep(4);
    } catch {
      setError('We could not send the booking notification. Please try again.');
    }
  };

  const resetBooking = () => {
    setStep(1);
    setSelectedSlot('');
    setDetails({ day: '', slot: '', name: '', phone: '', email: '' });
    setError('');
  };

  const copyUpiId = async () => {
    await navigator.clipboard?.writeText(UPI_ID);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1800);
  };

  return (
    <section id="booking" className="relative overflow-hidden bg-[#171512] py-24 text-[#f6f0e5] md:py-32">
      <div className="absolute -left-40 top-28 h-80 w-80 rounded-full border border-[#e7b94b]/15" />
      <div className="container-wide relative">
        <div className="grid gap-14 lg:grid-cols-[0.72fr_1.28fr] lg:gap-24">
          <div>
            <p className="section-kicker text-[#e7b94b]">One good conversation</p>
            <h2 className="display-font mt-5 text-6xl font-bold leading-[0.88] tracking-[-0.06em] md:text-8xl">Let’s put your shop on the map.</h2>
            <p className="mt-7 max-w-sm text-base leading-relaxed text-[#e9e1d4]/65">Select a slot. We’ll ask for the essentials. Then we get to work.</p>
            <div className="mt-12 flex items-start gap-3 border-t border-white/15 pt-5 text-sm text-[#e9e1d4]/75">
              <ShieldCheck className="mt-0.5 shrink-0 text-[#e7b94b]" size={18} />
              <span>No pressure. Your details are only used to arrange this build.</span>
            </div>
          </div>

          <div className="rounded-[1.5rem] bg-[#f4eee3] p-5 text-[#171512] sm:p-8 md:p-10">
            {step < 4 && (
              <div className="mb-9 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {[1, 2, 3].map((number) => <span key={number} className={`h-2 w-10 rounded-full transition-colors ${step >= number ? 'bg-[#d1a43c]' : 'bg-[#171512]/15'}`} />)}
                </div>
                <span className="text-xs font-bold uppercase tracking-[0.16em] text-[#6d665d]">Step {step} of 3</span>
              </div>
            )}

            {step === 1 && (
              <div>
                <div className="mb-8">
                  <p className="section-kicker text-[#9a721b]">01 / Choose a service</p>
                  <div className="mt-4 flex items-center justify-between gap-4 rounded-xl border-2 border-[#d1a43c] bg-[#e7b94b]/10 p-5">
                    <div><h3 className="display-font text-xl font-bold">E-commerce website</h3><p className="mt-1 text-sm text-[#6d665d]">Delivery: 1 day</p></div>
                    <div className="text-right"><p className="display-font text-2xl font-bold">₹5,999</p><p className="text-xs text-[#6d665d]">per website</p></div>
                  </div>
                </div>
                <div>
                  <p className="section-kicker text-[#9a721b]">02 / Pick a day</p>
                  <div className="mt-4 grid grid-cols-4 gap-2 sm:grid-cols-7">
                    {availableDays.map((day) => (
                      <button type="button" key={day.iso} onClick={() => setSelectedDay(day.iso)} className={`focus-ring rounded-lg border p-2 text-center transition-colors ${selectedDay === day.iso ? 'border-[#171512] bg-[#171512] text-[#f4eee3]' : 'border-[#171512]/15 hover:border-[#9a721b]'}`} data-testid={`button-day-${day.iso}`}>
                        <span className="block text-[0.65rem] font-bold uppercase tracking-wider opacity-60">{day.weekday}</span>
                        <span className="mt-1 block text-sm font-bold">{day.date.split(' ')[0]}</span>
                        <span className="block text-[0.62rem] opacity-60">{day.date.split(' ')[1]}</span>
                      </button>
                    ))}
                  </div>
                </div>
                <div className="mt-8">
                  <p className="section-kicker text-[#9a721b]">03 / Pick a time</p>
                  <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-5">
                    {appointmentSlots.map((slot) => (
                      <button type="button" key={slot} onClick={() => { setSelectedSlot(slot); setError(''); }} className={`focus-ring rounded-lg border px-2 py-3 text-sm font-semibold transition-colors ${selectedSlot === slot ? 'border-[#171512] bg-[#171512] text-[#f4eee3]' : 'border-[#171512]/15 hover:border-[#9a721b]'}`} data-testid={`button-slot-${slot.replaceAll(' ', '-').toLowerCase()}`}>
                        {slot}
                      </button>
                    ))}
                  </div>
                </div>
                {error && <p className="mt-4 text-sm font-semibold text-[#a0392e]" role="alert" data-testid="status-booking-error">{error}</p>}
                <button type="button" onClick={goToDetails} className="focus-ring mt-8 inline-flex w-full items-center justify-center gap-3 rounded-full bg-[#d1a43c] px-5 py-4 text-sm font-bold transition-transform hover:-translate-y-0.5" data-testid="button-continue-details">
                  Continue <ArrowRight size={17} />
                </button>
              </div>
            )}

            {step === 2 && (
              <form onSubmit={goToPayment}>
                <button type="button" onClick={() => setStep(1)} className="focus-ring mb-7 inline-flex items-center gap-1 text-sm font-semibold text-[#6d665d] hover:text-[#171512]" data-testid="button-back-service"><ChevronLeft size={16} /> Change slot</button>
                <p className="section-kicker text-[#9a721b]">02 / Your details</p>
                <h3 className="display-font mt-3 text-4xl font-bold tracking-[-0.05em]">Who are we building for?</h3>
                <p className="mt-3 text-sm text-[#6d665d]">{chosenDay.full} at {selectedSlot}</p>
                <div className="mt-8 space-y-4">
                  <label className="block text-sm font-bold">Your name<input required value={details.name} onChange={(event) => updateDetail('name', event.target.value)} placeholder="e.g. Manoj Kumar" className="focus-ring mt-2 w-full rounded-lg border border-[#171512]/20 bg-transparent px-4 py-3 font-normal outline-none placeholder:text-[#171512]/35 focus:border-[#9a721b]" data-testid="input-customer-name" /></label>
                  <label className="block text-sm font-bold">Phone number<input required type="tel" value={details.phone} onChange={(event) => updateDetail('phone', event.target.value)} placeholder="10-digit mobile number" className="focus-ring mt-2 w-full rounded-lg border border-[#171512]/20 bg-transparent px-4 py-3 font-normal outline-none placeholder:text-[#171512]/35 focus:border-[#9a721b]" data-testid="input-customer-phone" /></label>
                  <label className="block text-sm font-bold">Email address<input required type="email" value={details.email} onChange={(event) => updateDetail('email', event.target.value)} placeholder="Where should we send the details?" className="focus-ring mt-2 w-full rounded-lg border border-[#171512]/20 bg-transparent px-4 py-3 font-normal outline-none placeholder:text-[#171512]/35 focus:border-[#9a721b]" data-testid="input-customer-email" /></label>
                </div>
                {error && <p className="mt-4 text-sm font-semibold text-[#a0392e]" role="alert" data-testid="status-details-error">{error}</p>}
                <button type="submit" className="focus-ring mt-8 inline-flex w-full items-center justify-center gap-3 rounded-full bg-[#d1a43c] px-5 py-4 text-sm font-bold transition-transform hover:-translate-y-0.5" data-testid="button-continue-payment">Continue to advance <ArrowRight size={17} /></button>
              </form>
            )}

            {step === 3 && (
              <div>
                <button type="button" onClick={() => setStep(2)} className="focus-ring mb-7 inline-flex items-center gap-1 text-sm font-semibold text-[#6d665d] hover:text-[#171512]" data-testid="button-back-details"><ChevronLeft size={16} /> Edit details</button>
                <p className="section-kicker text-[#9a721b]">03 / Advance payment</p>
                <h3 className="display-font mt-3 text-4xl font-bold tracking-[-0.05em]">A small handoff before we start.</h3>
                 <p className="mt-3 text-sm leading-relaxed text-[#6d665d]">Pay the advance using the UPI ID below, then tap done. We’ll email the owner with your booking details.</p>
                <div className="mt-7 rounded-xl border border-[#d1a43c] bg-[#e7b94b]/10 p-5">
                   <div className="flex items-start gap-3"><div className="rounded-full bg-[#e7b94b] p-2"><Phone size={16} /></div><div><p className="font-bold">UPI ID</p><p className="mt-1 break-all font-mono text-sm text-[#6d665d]">{UPI_ID}</p></div></div>
                   <div className="mt-5 flex flex-wrap items-center gap-4">
                     <a href={`upi://pay?pa=${encodeURIComponent(UPI_ID)}&pn=Shurya%20Developer&cu=INR`} className="focus-ring inline-flex items-center gap-2 rounded-full bg-[#171512] px-4 py-3 text-sm font-bold text-[#f4eee3]" data-testid="link-upi-pay">Pay via UPI <ArrowUpRight size={15} /></a>
                     <button type="button" onClick={copyUpiId} className="focus-ring inline-flex items-center gap-2 text-sm font-bold underline underline-offset-4" data-testid="button-copy-upi-id">{copied ? <Check size={15} /> : <Copy size={15} />} {copied ? 'UPI ID copied' : 'Copy UPI ID'}</button>
                   </div>
                </div>
                <div className="mt-7 flex items-center justify-between border-t border-[#171512]/15 pt-5"><span className="text-sm text-[#6d665d]">E-commerce website</span><span className="display-font text-2xl font-bold">₹5,999</span></div>
                 {error && <p className="mt-4 text-sm font-semibold text-[#a0392e]" role="alert" data-testid="status-payment-error">{error}</p>}
                  <button type="button" onClick={completeBooking} disabled={notifyBooking.isPending} className="focus-ring mt-7 inline-flex w-full items-center justify-center gap-3 rounded-full bg-[#171512] px-5 py-4 text-sm font-bold text-[#f4eee3] transition-transform hover:-translate-y-0.5 disabled:cursor-wait disabled:opacity-60" data-testid="button-complete-booking">
                    {notifyBooking.isPending ? 'Sending notification…' : 'Done'} <ArrowRight size={17} />
                 </button>
                  <p className="mt-3 text-center text-xs text-[#6d665d]">After you tap Done, we’ll send the booking details to the owner automatically.</p>
              </div>
            )}

            {step === 4 && (
              <div className="py-5 text-center">
                <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-[#e7b94b]"><CheckCircle2 size={32} /></div>
                <p className="section-kicker mt-7 text-[#9a721b]">Request received</p>
                <h3 className="display-font mt-3 text-5xl font-bold leading-[0.9] tracking-[-0.06em]" data-testid="status-booking-confirmed">You’re on the list.</h3>
                <p className="mx-auto mt-5 max-w-sm text-sm leading-relaxed text-[#6d665d]">We’ll reach out to {details.name} at {details.phone} to confirm the UPI advance and your build slot.</p>
                <div className="mx-auto mt-7 max-w-sm rounded-xl bg-[#171512] p-5 text-left text-[#f4eee3]">
                  <p className="text-xs font-bold uppercase tracking-[0.16em] text-[#e7b94b]">Your slot</p>
                  <p className="display-font mt-2 text-xl font-bold">{chosenDay.full}</p>
                  <p className="mt-1 text-sm text-[#f4eee3]/65">{selectedSlot} · E-commerce website</p>
                </div>
                 <p className="mt-6 text-center text-xs text-[#6d665d]">Notification sent automatically to the Shurya Developer owner.</p>
                <button type="button" onClick={resetBooking} className="focus-ring mt-8 block w-full text-sm font-bold text-[#6d665d] hover:text-[#171512]" data-testid="button-book-another">Book another slot</button>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}

function ContactSection() {
  return (
    <section className="bg-[#f4eee3] py-24 text-[#171512] md:py-32">
      <div className="container-wide">
        <div className="grid gap-12 lg:grid-cols-[0.85fr_1.15fr] lg:gap-20">
          <div>
            <p className="section-kicker text-[#9a721b]">We are showing your shop online</p>
            <h2 className="display-font mt-5 text-6xl font-bold leading-[0.88] tracking-[-0.06em] md:text-8xl">Come say<br />hello.</h2>
            <div className="mt-10 space-y-5 text-sm">
              <a href="tel:9650787601" className="focus-ring flex items-start gap-3 font-semibold hover:text-[#9a721b]" data-testid="link-contact-phone"><Phone size={17} className="mt-0.5 text-[#9a721b]" /> 9650787601</a>
              <div className="flex items-start gap-3"><MapPin size={17} className="mt-0.5 shrink-0 text-[#9a721b]" /><span>A17 Parvesh Nagar, Mubarakpur Dabas, Delhi</span></div>
              <div className="flex items-start gap-3"><Clock3 size={17} className="mt-0.5 text-[#9a721b]" /><span>Hours: 8 to 10</span></div>
            </div>
            <div className="mt-10 flex gap-3">
              <a href="tel:9650787601" className="focus-ring inline-flex items-center gap-2 rounded-full bg-[#171512] px-5 py-3 text-sm font-bold text-[#f4eee3] transition-transform hover:-translate-y-0.5" data-testid="button-call-us"><Phone size={15} /> Call us</a>
              <a href="https://instagram.com" target="_blank" rel="noreferrer" className="focus-ring inline-flex items-center justify-center rounded-full border border-[#171512]/20 p-3 transition-colors hover:border-[#9a721b] hover:text-[#9a721b]" aria-label="Instagram" data-testid="link-instagram"><Instagram size={17} /></a>
            </div>
          </div>
          <div className="min-h-[340px] overflow-hidden rounded-[1.5rem] border border-[#171512]/15 bg-[#ded2bf]">
            <iframe title="Map showing A17 Parvesh Nagar, Mubarakpur Dabas, Delhi" src="https://www.google.com/maps?q=A17+Parvesh+Nagar,+Mubarakpur+Dabas,+Delhi&output=embed" className="h-full min-h-[340px] w-full grayscale-[0.2]" loading="lazy" data-testid="map-location" />
          </div>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="border-t border-white/15 bg-[#171512] py-8 text-[#f4eee3]">
      <div className="container-wide flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3"><AppMark small /><span className="display-font font-bold">Shurya Developer</span></div>
        <p className="text-xs text-[#f4eee3]/55">A small web agency for businesses ready to be found.</p>
        <a href="#top" className="focus-ring inline-flex items-center gap-2 text-xs font-bold uppercase tracking-[0.15em] text-[#e7b94b]" data-testid="link-back-top">Back to top <ArrowUpRight size={15} /></a>
      </div>
    </footer>
  );
}

function Home() {
  return (
    <main className="noise min-h-[100dvh] overflow-x-hidden">
      <Hero />
      <WorkSection />
      <ProcessSection />
      <BookingFlow />
      <ContactSection />
      <Footer />
    </main>
  );
}

function Router() {
  return (
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;